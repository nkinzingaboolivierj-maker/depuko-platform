import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.setGlobalPrefix('api/v1'); // §53: base path /api/v1
  await app.listen(process.env.API_PORT ?? 4000);
}
bootstrap();
